<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	require_once("thumbnail_images.class.php");

	 
	
	if(isset($_POST['submit']) and isset($_GET['add']))
	{
	
		 $home_banner=rand(0,99999)."_".$_FILES['home_banner']['name'];
		 $pic1=$_FILES['home_banner']['tmp_name'];

					
		 $tpath1='images/'.$home_banner; 
		 copy($pic1,$tpath1);
 
          
        $data = array( 
			    'home_title'  =>  $_POST['home_title'],
			    'home_url'  =>  $_POST['home_url'],			    
			   'home_banner'  =>  $home_banner
			    );		

 		$qry = Insert('tbl_home',$data);			

		$_SESSION['msg']="10";
 
		header( "Location:manage_home_slider.php");
		exit;	

		 
		
	}
	
	if(isset($_GET['slider_id']))
	{
			 
			$qry="SELECT * FROM tbl_home where id='".$_GET['slider_id']."'";
			$result=mysqli_query($mysqli,$qry);
			$row=mysqli_fetch_assoc($result);

	}
	if(isset($_POST['submit']) and isset($_POST['slider_id']))
	{
		 
		 if($_FILES['home_banner']['name']!="")
		 {		


				$img_res=mysqli_query($mysqli,'SELECT * FROM tbl_home WHERE id='.$_GET['slider_id'].'');
			    $img_res_row=mysqli_fetch_assoc($img_res);
			

			    if($img_res_row['home_banner']!="")
		        {
 					unlink('images/'.$img_res_row['home_banner']);
			     }

 				   $home_banner=rand(0,99999)."_".$_FILES['home_banner']['name'];
				   $pic1=$_FILES['home_banner']['tmp_name'];
				   $tpath1='images/'.$home_banner;
					
					copy($pic1,$tpath1);

					  
                    $data = array(
					    'home_title'  =>  $_POST['home_title'],
					    'home_url'  =>  $_POST['home_url'],
					    'home_banner'  =>  $home_banner
						);

					$category_edit=Update('tbl_home', $data, "WHERE id = '".$_POST['slider_id']."'");

		 }
		 else
		 {

					 $data = array(
			          'home_title'  =>  $_POST['home_title'],
			          'home_url'  =>  $_POST['home_url']
						);	
 
			         $category_edit=Update('tbl_home', $data, "WHERE id = '".$_POST['slider_id']."'");

		 }

		   

 						$_SESSION['msg']="11"; 
						header( "Location:add_slider.php?slider_id=".$_POST['slider_id']);
						exit;
 
	}


?>
<div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title"><?php if(isset($_GET['slider_id'])){?>Edit<?php }else{?>Add<?php }?> Slider</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom"> 
            <form action="" name="addeditcategory" method="post" class="form form-horizontal" enctype="multipart/form-data">
            	<input  type="hidden" name="slider_id" value="<?php echo $_GET['slider_id'];?>" />

              <div class="section">
                <div class="section-body">
                  <div class="form-group">
                    <label class="col-md-3 control-label">Title :-</label>
                    <div class="col-md-6">
                      <input type="text" name="home_title" id="home_title" value="<?php if(isset($_GET['slider_id'])){echo $row['home_title'];}?>" class="form-control" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-md-3 control-label">URL :-</label>
                    <div class="col-md-6">
                      <input type="text" name="home_url" id="home_url" value="<?php if(isset($_GET['slider_id'])){echo $row['home_url'];}?>" class="form-control" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-md-3 control-label">Select Image :-</label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input type="file" name="home_banner" value="" id="fileupload">
                        <?php if(isset($_GET['slider_id']) and $row['home_banner']!="") {?>
                        	  <div class="fileupload_img"><img type="image" src="images/<?php echo $row['home_banner'];?>" alt="category image" /></div>
                        	<?php } else {?>
                        	  <div class="fileupload_img"><img type="image" src="assets/images/add-image.png" alt="category image" /></div>
                        	<?php }?>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
