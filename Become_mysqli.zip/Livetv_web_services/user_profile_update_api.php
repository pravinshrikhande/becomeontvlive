<?php include("includes/connection.php");
 
	include('includes/function.php');

 	 
 	 	if (!filter_var($_GET['email'], FILTER_VALIDATE_EMAIL)) 
		{
			$set['LIVETV'][]=array('msg' => "Invalid email format!",'success'=>'0');
		}
 	 	else if($_GET['password']!="")
		{
			$data = array(
			'name'  =>  $_GET['name'],
			'email'  =>  $_GET['email'],
			'password'  =>  $_GET['password'],
			'phone'  =>  $_GET['phone']
			);
		}
		else
		{
			$data = array(
			'name'  =>  $_GET['name'],
			'email'  =>  $_GET['email'],			 
			'phone'  =>  $_GET['phone']
			);
		}
 
		
		$user_edit=Update('tbl_users', $data, "WHERE id = '".$_GET['user_id']."'");
 		 
	  				 
	$set['LIVETV'][]=array('msg'=>'Updated','success'=>'1');		 
		 

	header( 'Content-Type: application/json; charset=utf-8' );
	$json = json_encode($set);
	echo $json;
	 exit;
	 
?>