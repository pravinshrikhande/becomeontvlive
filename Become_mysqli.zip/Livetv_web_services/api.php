<?php include("includes/connection.php");
 	  include("includes/function.php"); 	
	
 	if(isset($_GET['home']))
	{
		$jsonObj_0= array();	 
 
		$query_home="SELECT * FROM tbl_home ORDER BY tbl_home.id";
		$sql_home = mysqli_query($mysqli,$query_home)or die(mysqli_error());

		while($data_home = mysqli_fetch_assoc($sql_home))
		{
			 
			$row0['home_title'] = $data_home['home_title'];
			$row0['home_banner'] = $data_home['home_banner'];
			$row0['home_url'] = $data_home['home_url'];

			array_push($jsonObj_0,$row0);
			  
		}

		$row['slider_list']=$jsonObj_0; 

 		$jsonObj= array();	

		$query="SELECT * FROM tbl_channels
		LEFT JOIN tbl_category ON tbl_channels.cat_id= tbl_category.cid 
		WHERE tbl_channels.status=1 ORDER BY tbl_channels.id DESC LIMIT 3";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row1['id'] = $data['id'];
			$row1['cat_id'] = $data['cat_id'];
			$row1['channel_title'] = $data['channel_title'];
			$row1['channel_url'] = $data['channel_url'];
			$row1['channel_thumbnail'] = $data['channel_thumbnail'];
			$row1['channel_desc'] = $data['channel_desc'];

			$row1['cid'] = $data['cid'];
			$row1['category_name'] = $data['category_name'];
			$row1['category_image'] = $data['category_image']; 
			 
			 
			array_push($jsonObj,$row1);
		
		}

		$row['latest_channels']=$jsonObj;


		$jsonObj_2= array();	

		$query_all="SELECT * FROM tbl_channels
		LEFT JOIN tbl_category ON tbl_channels.cat_id= tbl_category.cid
		WHERE tbl_channels.featured_channel=1 AND tbl_channels.status=1 ORDER BY tbl_channels.id DESC";

		$sql_all = mysqli_query($mysqli,$query_all)or die(mysqli_error());

		while($data_all = mysqli_fetch_assoc($sql_all))
		{
			$row2['id'] = $data_all['id'];
			$row2['cat_id'] = $data_all['cat_id'];
			$row2['channel_title'] = $data_all['channel_title'];
			$row2['channel_url'] = $data_all['channel_url'];
			$row2['channel_thumbnail'] = $data_all['channel_thumbnail'];
			$row2['channel_desc'] = $data_all['channel_desc'];

			$row2['cid'] = $data_all['cid'];
			$row2['category_name'] = $data_all['category_name'];
			$row2['category_image'] = $data_all['category_image'];
			
			

			array_push($jsonObj_2,$row2);
		
		}

		$row['featured_channels']=$jsonObj_2; 

		$set['LIVETV'] = $row;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	}
	else if(isset($_GET['cat_id']))
	{
		$post_order_by=API_CAT_POST_ORDER_BY;

		$cat_id=$_GET['cat_id'];	

		$jsonObj= array();	
	
	    $query="SELECT * FROM tbl_channels
		LEFT JOIN tbl_category ON tbl_channels.cat_id= tbl_category.cid 
		WHERE tbl_channels.cat_id='".$cat_id."' AND tbl_channels.status=1 ORDER BY tbl_channels.".$post_order_by."";

		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];
			$row['channel_title'] = $data['channel_title'];
			$row['channel_url'] = $data['channel_url'];
			$row['channel_thumbnail'] = $data['channel_thumbnail'];
			$row['channel_desc'] = $data['channel_desc'];

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $data['category_image'];
			 

			array_push($jsonObj,$row);
		
		}

		$set['LIVETV'] = $jsonObj;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

		
	}
	else if(isset($_GET['report']))
	{
		$report=$_GET['report'];   
		
		if($report)
		{
			$data = array( 															 
				    'name'  => $_GET['name'],				    
					'email'  =>  $_GET['email'],					
					'channel_id'  =>  $_GET['channel_id'], 
					'report'  =>  $report
					);		
 			 

			$qry = Insert('tbl_reports',$data);	
				
			$set['LIVETV'][] = array('msg' => 'Report has been sent successfully...','success'=>'1');
		}
		else
		{
			$set['LIVETV'][] = array('msg' => 'Please add report text','success'=>'0');
		}
		

    	header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	}
	else if(isset($_GET['latest']))
	{
		//$limit=$_GET['latest'];	 

		$limit=API_LATEST_LIMIT;

		$jsonObj= array();	

		$query="SELECT * FROM tbl_channels
		LEFT JOIN tbl_category ON tbl_channels.cat_id= tbl_category.cid 
		WHERE tbl_channels.status=1 ORDER BY tbl_channels.id DESC LIMIT $limit";
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			$row['id'] = $data['id'];
			$row['cat_id'] = $data['cat_id'];
			$row['channel_title'] = $data['channel_title'];
			$row['channel_url'] = $data['channel_url'];
			$row['channel_thumbnail'] = $data['channel_thumbnail'];
			$row['channel_desc'] = $data['channel_desc'];

			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $data['category_image'];
			 

			array_push($jsonObj,$row);
		
		}

		$set['LIVETV'] = $jsonObj;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	}		
	else if(isset($_GET['search']))
	{
		$jsonObj= array();	

		$query="SELECT * FROM tbl_channels
		LEFT JOIN tbl_category ON tbl_channels.cat_id= tbl_category.cid 
		WHERE tbl_channels.status=1 AND channel_title like '%".$_GET['search']."%' ";
		$sql = mysqli_query($mysqli,$query);
		
		if(mysqli_num_rows($sql)>0){

				while($data = mysqli_fetch_assoc($sql))
				{
					$row['id'] = $data['id'];
					$row['cat_id'] = $data['cat_id'];
					$row['channel_title'] = $data['channel_title'];
					$row['channel_url'] = $data['channel_url'];
					$row['channel_thumbnail'] = $data['channel_thumbnail'];
					$row['channel_desc'] = $data['channel_desc'];

					$row['cid'] = $data['cid'];
					$row['category_name'] = $data['category_name'];
					$row['category_image'] = $data['category_image'];
					 

					array_push($jsonObj,$row);
				
				}

				$set['LIVETV'] = $jsonObj;
				
				header( 'Content-Type: application/json; charset=utf-8' );
			    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
				die();

		}
		else
		{
			    $set['LIVETV'][]=array('msg' => 'No Channel Found! Try Different Keyword','Success'=>'0');

		  	    header( 'Content-Type: application/json; charset=utf-8' );
			    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
				die();
		}
	
	}
	else if(isset($_GET['channel_id']))
	{
		 //echo $_GET['channel_id'];
		$SQL1="select * from tbl_channels where id='".$_GET['channel_id']."'";	
		$result1 = mysqli_query($mysqli,$SQL1)or die(mysqli_error());	
						
			$jsonObj= array();

			while ($row1 = mysqli_fetch_assoc($result1)) 
			{
	  
					$catArr=array();
					$catArr['id'] = $row1['id'];
					$catArr['cat_id'] = $row1['cat_id'];
					$catArr['channel_type'] = $row1['channel_type'];
					$catArr['channel_title'] = $row1['channel_title'];
					$catArr['channel_url'] = $row1['channel_url'];
					$catArr['channel_thumbnail'] = $row1['channel_thumbnail'];
					$catArr['channel_desc'] = $row1['channel_desc'];
					
					$SQL2 = "SELECT * FROM tbl_channels WHERE cat_id = '".$row1['cat_id']."'";
	       			$result2 = mysqli_query($mysqli,$SQL2);
					
					$subvidArr=array();
					while ($row2 = mysqli_fetch_assoc($result2)) 
					{	
	 					if($row1['id'] != $row2['id'])
						{									
						$temp = array('rel_id' => $row2['id'], 'rel_channel_title' => $row2['channel_title'] , 'rel_channel_url' =>$row2['channel_url'],
						 'rel_channel_thumbnail' => $row2['channel_thumbnail']);
						$subvidArr[]=$temp;
						}
					}
					$catArr['related']=$subvidArr;								 
	  				array_push($jsonObj,$catArr);
	  
			}
				 
				
		$set['LIVETV'] = $jsonObj;				

		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();
 

	}
	else if(isset($_GET['app_details']))
	{
		$jsonObj= array();	

		$query="SELECT * FROM tbl_settings WHERE id='1'";
		$sql = mysqli_query($mysqli,$query)or die(mysqli_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			 
			$row['app_name'] = $data['app_name'];
			$row['app_logo'] = $data['app_logo'];
			$row['app_version'] = $data['app_version'];
			$row['app_author'] = $data['app_author'];
			$row['app_contact'] = $data['app_contact'];
			$row['app_email'] = $data['app_email'];
			$row['app_website'] = $data['app_website'];
			$row['app_description'] = $data['app_description'];
			$row['app_developed_by'] = $data['app_developed_by'];

			$row['app_privacy_policy'] = $data['app_privacy_policy'];
 

			array_push($jsonObj,$row);
		
		}

		$set['LIVETV'] = $jsonObj;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();	
	}		
	else
	{
		 
		$jsonObj= array();
		
		$cid=API_CAT_ORDER_BY;


		$query="SELECT cid,category_name,category_image FROM tbl_category ORDER BY tbl_category.".$cid."";
		$sql = mysqli_query($mysqli,$query)or die(mysql_error());

		while($data = mysqli_fetch_assoc($sql))
		{
			
			$row['cid'] = $data['cid'];
			$row['category_name'] = $data['category_name'];
			$row['category_image'] = $data['category_image'];
			 

			array_push($jsonObj,$row);
		
		}

		$set['LIVETV'] = $jsonObj;
		
		header( 'Content-Type: application/json; charset=utf-8' );
	    echo $val= str_replace('\\/', '/', json_encode($set,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
		die();

	} 
	 
?>