-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2017 at 07:56 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `livetv_web_services`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `email`, `image`) VALUES
(1, 'admin', 'admin', 'viaviwebtech@gmail.com', 'profile.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cid` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cid`, `category_name`, `category_image`) VALUES
(1, 'Sports Channel', '86578_Sports.png'),
(2, 'Fashion Channel', '94282_fashionchannels.png'),
(3, 'Entertainment Channel', '79517_entertainmentchannel.png'),
(4, 'News Channel', '14243_news.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_channels`
--

CREATE TABLE `tbl_channels` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `channel_type` varchar(255) NOT NULL,
  `channel_title` varchar(100) NOT NULL,
  `channel_url` varchar(255) NOT NULL,
  `channel_thumbnail` varchar(255) NOT NULL,
  `channel_desc` varchar(255) NOT NULL,
  `featured_channel` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_channels`
--

INSERT INTO `tbl_channels` (`id`, `cat_id`, `channel_type`, `channel_title`, `channel_url`, `channel_thumbnail`, `channel_desc`, `featured_channel`, `status`) VALUES
(1, 1, 'live_url', 'Ten Sports', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '24432_ten-sports-tv-logo-design-uk.png', '<p>Ten Sports Live - Watch live tournaments, matches, events of your favorite sports online.</p>\r\n', 0, 1),
(2, 1, 'live_url', 'Sony Six', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '94013_SonySix.png', 'Watch Sony Six Live Streaming,Sony Six Tv Live.\r\n\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and s', 0, 1),
(3, 2, 'live_url', 'f.Diamond', 'http://edgeb.streaming.sk/fashiontv/fashiontv.stream/playlist_b125000_w304569164.m3u8', '34851_fdai.jpg', 'f.Diamond - International network dedicated to fashion news, shows, models and designers broadcasting 24 hours a day.', 0, 1),
(4, 2, 'live_url', 'Fashion TV', 'http://edgeb.streaming.sk/fashiontv/fashiontv.stream/playlist_b125000_w304569164.m3u8', '81756_fash.jpg', 'FashionTV Live. Stay tuned for your favorite FashionTV programs and all the latest from the worlds major fashion and celebrity events.', 0, 1),
(5, 4, 'live_url', 'NewsX', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '49319_news-x-logo.jpg', '<p>NewsX - Best English News Channel of the year 2014. Get the latest IT news, latest breaking news, current affairs, politics, business, technology etc..</p>\r\n', 0, 1),
(6, 4, 'live_url', 'Times Now', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '16393_timees.png', 'TIMES NOW is a Leading 24-hour English News channel that provides complete live coverage of international news, business news, breaking news..', 0, 1),
(8, 3, 'live_url', 'MTV', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '88773_mtv.png', 'MTV gives you the hottest buzz from the entertainment world that will keep you hooked! Be the first to catch the latest MTV shows, music, artists and more!', 1, 1),
(9, 3, 'live_url', 'Star TV', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '33560_13129605_274865709522504_1583429812_n.jpg', '<p>Star TV is all about News, Entertainment, Lifestyle and Cooking shows...</p>\r\n', 0, 1),
(10, 3, 'live_url', 'TRT HABER', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '19501_trthaber.png', 'TRT new face in the world of the Internet, international and local news, domestic news, foreign news...', 0, 1),
(11, 3, 'live_url', 'TV8', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '58533_tv8.jpg', 'TV8 offers over 100 television channels, a comprehensive program. TV8, watch high quality TV, HD quality watch TV 8. ', 0, 1),
(12, 3, 'live_url', '9XM', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '51046_9xM.jpg', '<p>Bollywood Music at its best, thats what 9XM is all about.</p>\r\n', 1, 1),
(13, 1, 'live_url', 'ESPN', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '44261_espn.png', 'Get the latest NBA basketball news, scores, stats, standings, fantasy games, and more from ESPN', 1, 1),
(14, 1, 'live_url', 'Star Sports', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native', '17953_star-sports-1.jpg', '<p>Watch Star Sports Live Streaming.</p>\r\n', 1, 1),
(15, 4, 'youtube', 'Aajtak Live TV', 'https://www.youtube.com/watch?v=oMETNh3Tr0Q', '134_aaj_tak_hd.png', '<p>Aaj Tak has been awarded &#39;News Channel of the Year - Hindi&#39; (News Broadcasting Awards 2016 - ENBA Awards)</p>\r\n', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_home`
--

CREATE TABLE `tbl_home` (
  `id` int(11) NOT NULL,
  `home_title` varchar(255) NOT NULL,
  `home_banner` varchar(255) NOT NULL,
  `home_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_home`
--

INSERT INTO `tbl_home` (`id`, `home_title`, `home_banner`, `home_url`) VALUES
(1, 'Star Sports', '27783_Star_Sports.png', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native'),
(3, 'ABP News', '88806_abp_english.jpg', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reports`
--

CREATE TABLE `tbl_reports` (
  `id` int(11) NOT NULL,
  `channel_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `report` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_logo` varchar(255) NOT NULL,
  `app_email` varchar(255) NOT NULL,
  `app_version` varchar(255) NOT NULL,
  `app_author` varchar(255) NOT NULL,
  `app_contact` varchar(255) NOT NULL,
  `app_website` varchar(255) NOT NULL,
  `app_description` text NOT NULL,
  `app_developed_by` varchar(255) NOT NULL,
  `app_privacy_policy` text NOT NULL,
  `api_latest_limit` int(3) NOT NULL,
  `api_cat_order_by` varchar(255) NOT NULL,
  `api_cat_post_order_by` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `app_name`, `app_logo`, `app_email`, `app_version`, `app_author`, `app_contact`, `app_website`, `app_description`, `app_developed_by`, `app_privacy_policy`, `api_latest_limit`, `api_cat_order_by`, `api_cat_post_order_by`) VALUES
(1, 'Live TV App', 'app_logo.png', 'info@viaviweb.in', '2.1.5', 'viaviwebtech', '+91 1234567891', 'www.viaviweb.com', '<p>Watch your favorite TV channels Live in your mobile phone with this Android application on your Android device. that support almost all format.The application is specially optimized to be extremely easy to configure and detailed documentation is provided.</p>\r\n', 'Viaviweb', '<p><strong>We are committed to protecting your privacy</strong></p>\r\n\r\n<p>We collect the minimum amount of information about you that is commensurate with providing you with a satisfactory service. This policy indicates the type of processes that may result in data being collected about you. Your use of this website gives us the right to collect that information.&nbsp;</p>\r\n\r\n<p><strong>Information Collected</strong></p>\r\n\r\n<p>We may collect any or all of the information that you give us depending on the type of transaction you enter into, including your name, address, telephone number, and email address, together with data about your use of the website. Other information that may be needed from time to time to process a request may also be collected as indicated on the website.</p>\r\n\r\n<p><strong>Information Use</strong></p>\r\n\r\n<p>We use the information collected primarily to process the task for which you visited the website. Data collected in the UK is held in accordance with the Data Protection Act. All reasonable precautions are taken to prevent unauthorised access to this information. This safeguard may require you to provide additional forms of identity should you wish to obtain information about your account details.</p>\r\n\r\n<p><strong>Cookies</strong></p>\r\n\r\n<p>Your Internet browser has the in-built facility for storing small files - &quot;cookies&quot; - that hold information which allows a website to recognise your account. Our website takes advantage of this facility to enhance your experience. You have the ability to prevent your computer from accepting cookies but, if you do, certain functionality on the website may be impaired.</p>\r\n\r\n<p><strong>Disclosing Information</strong></p>\r\n\r\n<p>We do not disclose any personal information obtained about you from this website to third parties unless you permit us to do so by ticking the relevant boxes in registration or competition forms. We may also use the information to keep in contact with you and inform you of developments associated with us. You will be given the opportunity to remove yourself from any mailing list or similar device. If at any time in the future we should wish to disclose information collected on this website to any third party, it would only be with your knowledge and consent.&nbsp;</p>\r\n\r\n<p>We may from time to time provide information of a general nature to third parties - for example, the number of individuals visiting our website or completing a registration form, but we will not use any information that could identify those individuals.&nbsp;</p>\r\n\r\n<p>In addition Dummy may work with third parties for the purpose of delivering targeted behavioural advertising to the Dummy website. Through the use of cookies, anonymous information about your use of our websites and other websites will be used to provide more relevant adverts about goods and services of interest to you. For more information on online behavioural advertising and about how to turn this feature off, please visit youronlinechoices.com/opt-out.</p>\r\n\r\n<p><strong>Changes to this Policy</strong></p>\r\n\r\n<p>Any changes to our Privacy Policy will be placed here and will supersede this version of our policy. We will take reasonable steps to draw your attention to any changes in our policy. However, to be on the safe side, we suggest that you read this document each time you use the website to ensure that it still meets with your approval.</p>\r\n\r\n<p><strong>Contacting Us</strong></p>\r\n\r\n<p>If you have any questions about our Privacy Policy, or if you want to know what information we have collected about you, please email us at hd@dummy.com. You can also correct any factual errors in that information or require us to remove your details form any list under our control.</p>\r\n', 10, 'category_name', 'channel_title');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `confirm_code` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_type`, `name`, `email`, `password`, `phone`, `confirm_code`, `status`) VALUES
(5, 'Normal', 'John Deo', 'johndeo@gmail.com', 'kelvin', '9123456789', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_version`
--

CREATE TABLE `tbl_version` (
  `vid` int(11) NOT NULL,
  `version_code` varchar(255) NOT NULL,
  `version_messages` varchar(255) NOT NULL,
  `version_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_version`
--

INSERT INTO `tbl_version` (`vid`, `version_code`, `version_messages`, `version_url`) VALUES
(1, '2', 'New Update Available please download it.', 'https://www.google.co.in/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_channels`
--
ALTER TABLE `tbl_channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_home`
--
ALTER TABLE `tbl_home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_version`
--
ALTER TABLE `tbl_version`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_channels`
--
ALTER TABLE `tbl_channels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_home`
--
ALTER TABLE `tbl_home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_version`
--
ALTER TABLE `tbl_version`
  MODIFY `vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
