<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	
	//Get all data 
	$qry="SELECT * FROM tbl_home";
	$result=mysqli_query($mysqli,$qry);
	
	if(isset($_GET['slider_id']))
	{
 
		$img_res=mysqli_query($mysqli,'SELECT * FROM tbl_home WHERE id=\''.$_GET['slider_id'].'\'');
		$img_res_row=mysqli_fetch_assoc($img_res);


		if($img_res_row['home_banner']!="")
	    {
	    	unlink('images/'.$img_res_row['home_banner']);
			 

		}
 
		Delete('tbl_home','id='.$_GET['slider_id'].'');

		$_SESSION['msg']="12";
		header( "Location:manage_home_slider.php");
		exit;
		
	}	
	 
?>
                
    <div class="row">
      <div class="col-xs-12">
        <div class="card mrg_bottom">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title">Manage Slider</div>
            </div>
            <div class="col-md-7 col-xs-12">
              <div class="search_list">
                
                <div class="add_btn_primary"> <a href="add_slider.php?add=yes">Add Slider</a> </div>
              </div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="col-md-12 mrg-top">
            <table class="table table-striped table-bordered table-hover">
              <thead>
                <tr>                  
                  <th>Title</th>
                  <th>Image</th>
                  <th class="cat_action_list">Action</th>
                </tr>
              </thead>
              <tbody>
              	<?php	
						$i=0;
						while($row=mysqli_fetch_array($result))
						{					
				?>
                <tr>                 
                  <td><?php echo $row['home_title'];?></td>
                  <td><span class="category_img"><img src="images/<?php echo $row['home_banner'];?>" style="width: 150px;height: 100px;" /></span></td>
                  <td><a href="add_slider.php?slider_id=<?php echo $row['id'];?>" class="btn btn-primary">Edit</a>
                    <a href="?slider_id=<?php echo $row['id'];?>" class="btn btn-default" onclick="return confirm('Are you sure you want to delete this category and related channel?');">Delete</a></td>
                </tr>
                <?php
						
						$i++;
				     	}
				?> 
              </tbody>
            </table>
          </div>
           
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
