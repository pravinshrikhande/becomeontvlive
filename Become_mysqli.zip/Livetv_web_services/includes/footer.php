<footer class="app-footer">
      <div class="row">
        <div class="col-xs-12">
		<?php
		//echo SITE_URL;
		?>
          <div class="footer-copyright">Copyright © <?php echo date('Y');?>
		  <a href="http://<?php echo SITE;?>" target="_blank"><?php echo APP_NAME;?></a>. All Rights Reserved.
		  </div>
        </div>
      </div>
    </footer>
  </div>
</div>
<script type="text/javascript" src="assets/js/vendor.js"></script> 
<script type="text/javascript" src="assets/js/app.js"></script>
</body>
</html>